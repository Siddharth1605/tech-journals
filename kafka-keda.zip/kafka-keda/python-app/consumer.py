from kafka import KafkaConsumer
import json
import time

consumer = KafkaConsumer(
    "orders",
    bootstrap_servers=["redpanda:9092"],
    group_id="orders-group",
    auto_offset_reset="earliest",
    enable_auto_commit=True,
    value_deserializer=lambda m: json.loads(m.decode("utf-8"))
)

print("Consumer Started")

for msg in consumer:
    print("Received:", msg.value)

    # simulate heavy processing
    time.sleep(5)

    print("Processed")
