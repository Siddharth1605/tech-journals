from kafka import KafkaProducer
import json
import time

producer = KafkaProducer(
    bootstrap_servers="redpanda:9092",
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

counter = 1

while True:
    msg = {
        "orderId": counter
    }

    producer.send("orders", msg)
    producer.flush()

    print(f"Produced: {msg}")

    counter += 1

