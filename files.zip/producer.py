"""
Demo Kafka producer.

Sends one JSON message to the configured topic every PRODUCE_INTERVAL_SECONDS.
Designed to die IMMEDIATELY on SIGTERM (i.e. the instant `kubectl delete deployment`
or a pod termination happens) instead of finishing an in-flight sleep/loop first.

Env vars (all optional, sane defaults for the demo):
  KAFKA_BOOTSTRAP_SERVERS   default: kafka.keda-scaling.svc.cluster.local:9092
  KAFKA_TOPIC               default: demo-topic
  PRODUCE_INTERVAL_SECONDS  default: 0.2   (fast, so lag builds up quickly for the demo)
"""

import json
import os
import signal
import sys
import time
from datetime import datetime, timezone

from kafka import KafkaProducer
from kafka.errors import NoBrokersAvailable

BOOTSTRAP_SERVERS = os.environ.get("KAFKA_BOOTSTRAP_SERVERS", "kafka.keda-scaling.svc.cluster.local:9092")
TOPIC = os.environ.get("KAFKA_TOPIC", "demo-topic")
INTERVAL_SECONDS = float(os.environ.get("PRODUCE_INTERVAL_SECONDS", "0.2"))

_shutdown = False


def _handle_signal(signum, frame):
    """SIGTERM handler: flip a flag so the loop exits on its very next check,
    instead of waiting out the current sleep. This is what makes the producer
    stop "immediately" the moment the Deployment/pod is deleted."""
    global _shutdown
    print(f"[producer] received signal {signum}, shutting down immediately", flush=True)
    _shutdown = True


def connect_with_retry():
    while not _shutdown:
        try:
            producer = KafkaProducer(
                bootstrap_servers=BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode("utf-8"),
                linger_ms=0,
                acks="1",
            )
            print(f"[producer] connected to {BOOTSTRAP_SERVERS}", flush=True)
            return producer
        except NoBrokersAvailable:
            print("[producer] kafka not reachable yet, retrying in 3s...", flush=True)
            time.sleep(3)
    sys.exit(0)


def main():
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    producer = connect_with_retry()
    counter = 0

    print(f"[producer] sending to topic='{TOPIC}' every {INTERVAL_SECONDS}s", flush=True)

    while not _shutdown:
        counter += 1
        message = {
            "id": counter,
            "sent_at": datetime.now(timezone.utc).isoformat(),
            "payload": f"demo-message-{counter}",
        }
        try:
            producer.send(TOPIC, value=message)
            producer.flush(timeout=2)
            print(f"[producer] sent message {counter}", flush=True)
        except Exception as exc:
            print(f"[producer] send failed: {exc}", flush=True)

        # Sleep in small increments so shutdown is picked up fast even if
        # PRODUCE_INTERVAL_SECONDS is set higher than a second or two.
        slept = 0.0
        step = 0.1
        while slept < INTERVAL_SECONDS and not _shutdown:
            time.sleep(step)
            slept += step

    print("[producer] flushing final buffer and exiting now", flush=True)
    try:
        producer.flush(timeout=1)
        producer.close(timeout=1)
    except Exception:
        pass
    print("[producer] terminated", flush=True)
    sys.exit(0)


if __name__ == "__main__":
    main()
