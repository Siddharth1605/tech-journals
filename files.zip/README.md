# Kafka + KEDA autoscaling demo (namespace: `keda-scaling`)

## What you get
- Single-broker Kafka (KRaft mode, no Zookeeper) + Kafka UI
- `producer.py` — sends a message every 0.2s, dies **immediately** on `kubectl delete`
- `consumer.py` — consumer-group reader with a small artificial per-message delay
  so lag is visible in a demo
- A KEDA `ScaledObject` that scales the consumer Deployment 0 → 3 based on
  consumer-group lag on `demo-topic`, tuned for fast demo timing

## File layout
```
00-namespace.yaml
01-kafka/kafka.yaml              # Kafka StatefulSet + services
01-kafka/create-topic-job.yaml   # creates demo-topic (3 partitions)
02-kafka-ui/kafka-ui.yaml
03-producer/producer.py
03-producer/Dockerfile
03-producer/deployment.yaml
04-consumer/consumer.py
04-consumer/Dockerfile
04-consumer/deployment.yaml
05-keda/scaledobject.yaml
```

## Step 1 — Install KEDA (once per cluster)
```bash
helm repo add kedacore https://kedacore.github.io/charts
helm repo update
helm install keda kedacore/keda --namespace keda --create-namespace
kubectl get pods -n keda   # wait until Running
```

## Step 2 — Create the namespace
```bash
kubectl apply -f 00-namespace.yaml
```

## Step 3 — Deploy Kafka + create the topic
```bash
kubectl apply -f 01-kafka/kafka.yaml
kubectl -n keda-scaling rollout status statefulset/kafka
kubectl apply -f 01-kafka/create-topic-job.yaml
kubectl -n keda-scaling logs job/kafka-create-topic -f
```
`demo-topic` is created with 3 partitions — that's also why the ScaledObject
caps `maxReplicaCount` at 3 later: a partition can only be read by one
consumer pod within a group at a time, so more than 3 pods would just idle.

## Step 4 — Deploy Kafka UI (optional but handy for the demo)
```bash
kubectl apply -f 02-kafka-ui/kafka-ui.yaml
kubectl -n keda-scaling port-forward svc/kafka-ui 8080:8080
# open http://localhost:8080 — you can watch messages and consumer-group lag live
```

## Step 5 — Build and push the producer/consumer images
Replace `your-registry` with your actual registry (Docker Hub, GCR, etc.), then:
```bash
cd 03-producer
docker build -t your-registry/kafka-demo-producer:latest .
docker push your-registry/kafka-demo-producer:latest

cd ../04-consumer
docker build -t your-registry/kafka-demo-consumer:latest .
docker push your-registry/kafka-demo-consumer:latest
```
Then update the `image:` line in both `deployment.yaml` files to match.
(If you're on a local cluster like kind/minikube, load the images instead of
pushing: `kind load docker-image ...` / `minikube image load ...`.)

## Step 6 — Deploy the consumer + its KEDA ScaledObject FIRST
Deploy the consumer and the ScaledObject before the producer, so scaling is
visible from a cold start (0 replicas):
```bash
kubectl apply -f 04-consumer/deployment.yaml
kubectl apply -f 05-keda/scaledobject.yaml

kubectl -n keda-scaling get scaledobject
kubectl -n keda-scaling get hpa   # KEDA creates this HPA automatically
```
Within ~15s (cooldownPeriod) of no lag, KEDA will scale `kafka-consumer` down
to 0 replicas — this is expected and correct before the producer starts.

## Step 7 — Start the producer
```bash
kubectl apply -f 03-producer/deployment.yaml
kubectl -n keda-scaling get pods -w
```
Watch in a second terminal:
```bash
kubectl -n keda-scaling get hpa kafka-consumer-scaledobject -w
```
As soon as lag exceeds `activationLagThreshold` (1 message), KEDA scales the
consumer up from 0. As lag grows past `lagThreshold` (5 per replica), it
scales further, up to 3 replicas (one per partition).

## Step 8 — Demo the "producer deleted → stops immediately" behavior
```bash
kubectl -n keda-scaling delete deployment kafka-producer
```
Because:
- `producer.py` catches `SIGTERM` and breaks its send loop on the very next
  check (sleeps are done in 0.1s increments so this is near-instant), and
- `terminationGracePeriodSeconds: 5` is set low in the Deployment spec,

the pod stops sending and terminates almost immediately — no 30s hang.

## Step 9 — Watch the scale-down
Once the producer is gone, the consumer(s) keep draining the topic until lag
hits 0. Once lag is 0 for `cooldownPeriod` (15s), KEDA scales
`kafka-consumer` back down to 0 replicas.
```bash
kubectl -n keda-scaling get hpa kafka-consumer-scaledobject -w
```

## Tuning knobs (all set low on purpose for a snappy demo)
| Setting | Where | Demo value | Effect |
|---|---|---|---|
| `PRODUCE_INTERVAL_SECONDS` | producer deployment env | 0.2 | how fast lag builds |
| `PROCESS_DELAY_SECONDS` | consumer deployment env | 0.5 | how visibly lag builds per-message |
| `pollingInterval` | ScaledObject | 3 | how often KEDA checks Kafka lag |
| `cooldownPeriod` | ScaledObject | 15 | how long to wait at 0 lag before scaling down |
| `lagThreshold` | ScaledObject trigger | 5 | messages of lag per replica before adding another |
| `activationLagThreshold` | ScaledObject trigger | 1 | lag needed to go from 0 → 1 replica at all |
| `minReplicaCount` / `maxReplicaCount` | ScaledObject | 0 / 3 | scale range |

For a real (non-demo) workload you'd raise `cooldownPeriod` (avoid flapping),
raise `lagThreshold`, and drop `PROCESS_DELAY_SECONDS` to 0.

## Cleanup
```bash
kubectl delete namespace keda-scaling
```
