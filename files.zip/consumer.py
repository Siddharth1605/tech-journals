"""
Demo Kafka consumer.

Joins a consumer group and processes messages one at a time, committing offsets
as it goes. A small artificial delay per message (PROCESS_DELAY_SECONDS) is
included on purpose: it makes lag build up visibly while the producer is
running fast, so KEDA's scale-up is obvious in a demo. Set it to 0 for a
"real" fast consumer.

Env vars:
  KAFKA_BOOTSTRAP_SERVERS   default: kafka.keda-scaling.svc.cluster.local:9092
  KAFKA_TOPIC               default: demo-topic
  KAFKA_CONSUMER_GROUP      default: demo-consumer-group
  PROCESS_DELAY_SECONDS     default: 0.5
"""

import json
import os
import signal
import sys
import time

from kafka import KafkaConsumer
from kafka.errors import NoBrokersAvailable

BOOTSTRAP_SERVERS = os.environ.get("KAFKA_BOOTSTRAP_SERVERS", "kafka.keda-scaling.svc.cluster.local:9092")
TOPIC = os.environ.get("KAFKA_TOPIC", "demo-topic")
GROUP_ID = os.environ.get("KAFKA_CONSUMER_GROUP", "demo-consumer-group")
PROCESS_DELAY_SECONDS = float(os.environ.get("PROCESS_DELAY_SECONDS", "0.5"))

_shutdown = False


def _handle_signal(signum, frame):
    global _shutdown
    print(f"[consumer] received signal {signum}, shutting down after current message", flush=True)
    _shutdown = True


def connect_with_retry():
    while not _shutdown:
        try:
            consumer = KafkaConsumer(
                TOPIC,
                bootstrap_servers=BOOTSTRAP_SERVERS,
                group_id=GROUP_ID,
                value_deserializer=lambda v: json.loads(v.decode("utf-8")),
                enable_auto_commit=False,
                auto_offset_reset="earliest",
                max_poll_records=10,
                consumer_timeout_ms=1000,  # lets the loop check _shutdown periodically
            )
            print(f"[consumer] connected, group='{GROUP_ID}', topic='{TOPIC}'", flush=True)
            return consumer
        except NoBrokersAvailable:
            print("[consumer] kafka not reachable yet, retrying in 3s...", flush=True)
            time.sleep(3)
    sys.exit(0)


def main():
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    consumer = connect_with_retry()
    pod_name = os.environ.get("HOSTNAME", "unknown-pod")

    while not _shutdown:
        try:
            records = consumer.poll(timeout_ms=1000, max_records=10)
        except Exception as exc:
            print(f"[consumer] poll error: {exc}", flush=True)
            continue

        if not records:
            continue

        for tp, messages in records.items():
            for message in messages:
                if _shutdown:
                    break
                print(
                    f"[consumer:{pod_name}] partition={tp.partition} "
                    f"offset={message.offset} value={message.value}",
                    flush=True,
                )
                if PROCESS_DELAY_SECONDS > 0:
                    time.sleep(PROCESS_DELAY_SECONDS)
        consumer.commit()

    print("[consumer] closing consumer and exiting", flush=True)
    try:
        consumer.close()
    except Exception:
        pass
    print("[consumer] terminated", flush=True)
    sys.exit(0)


if __name__ == "__main__":
    main()
