package com.example.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class OrderConsumer {

    private final long processingDelayMs;

    public OrderConsumer(
            @Value("${app.processing-delay-ms:2000}") long processingDelayMs
    ) {
        this.processingDelayMs = processingDelayMs;
    }

    @KafkaListener(
            topics = "${app.topic:orders}",
            groupId = "${spring.kafka.consumer.group-id}"
    )
    public void consume(ConsumerRecord<String, String> record)
            throws InterruptedException {

        String podName = System.getenv()
                .getOrDefault("HOSTNAME", "local");

        System.out.printf(
                "[%s] START partition=%d offset=%d value=%s%n",
                podName,
                record.partition(),
                record.offset(),
                record.value()
        );

        // Deliberately slow processing so Kafka lag builds up and KEDA
        // has enough time to demonstrate scale-out.
        Thread.sleep(processingDelayMs);

        System.out.printf(
                "[%s] DONE  partition=%d offset=%d%n",
                podName,
                record.partition(),
                record.offset()
        );
    }
}
