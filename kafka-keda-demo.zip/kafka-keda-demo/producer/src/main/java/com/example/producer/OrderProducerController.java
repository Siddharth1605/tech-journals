package com.example.producer;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
public class OrderProducerController {

    private static final String TOPIC = "orders";

    private final KafkaTemplate<String, String> kafkaTemplate;

    public OrderProducerController(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @PostMapping("/publish/{count}")
    public ResponseEntity<String> publish(@PathVariable int count) {
        if (count < 1 || count > 100_000) {
            return ResponseEntity.badRequest()
                    .body("count must be between 1 and 100000");
        }

        CompletableFuture<?>[] sends = new CompletableFuture<?>[count];

        for (int i = 0; i < count; i++) {
            String orderId = UUID.randomUUID().toString();
            String message = "Order-" + orderId;

            // A null key allows Kafka's producer partitioner to spread records
            // across the six partitions.
            sends[i] = kafkaTemplate.send(
                    new ProducerRecord<>(TOPIC, null, message)
            );
        }

        CompletableFuture.allOf(sends).join();
        return ResponseEntity.accepted()
                .body(count + " orders published to topic " + TOPIC);
    }
}
