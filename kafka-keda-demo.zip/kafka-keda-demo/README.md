# Kafka + KEDA Demo

This project demonstrates:

Producer REST API -> Kafka `orders` topic -> Spring Boot consumer -> KEDA scaling based on Kafka consumer-group lag.

## Prerequisites

- Kubernetes/Minikube
- kubectl
- Helm
- Docker
- Java 21
- Maven 3.9+

KEDA should already be installed.

## 1. Deploy Kafka

```bash
kubectl apply -f k8s/kafka.yaml
kubectl rollout status deployment/kafka --timeout=180s
```

Create the topic:

```bash
kubectl exec deployment/kafka -- \
  /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server kafka:9092 \
  --create \
  --if-not-exists \
  --topic orders \
  --partitions 6 \
  --replication-factor 1
```

Verify:

```bash
kubectl exec deployment/kafka -- \
  /opt/kafka/bin/kafka-topics.sh \
  --bootstrap-server kafka:9092 \
  --describe \
  --topic orders
```

## 2. Build the Spring Boot projects

```bash
mvn -f producer/pom.xml clean package -DskipTests
mvn -f consumer/pom.xml clean package -DskipTests
```

## 3. Build images inside Minikube

```bash
eval $(minikube docker-env)

docker build -t kafka-producer:1.0 ./producer
docker build -t kafka-consumer:1.0 ./consumer
```

## 4. Deploy applications and KEDA scaler

```bash
kubectl apply -f k8s/producer.yaml
kubectl apply -f k8s/consumer.yaml
kubectl apply -f k8s/keda-scaled-object.yaml
```

Verify:

```bash
kubectl get pods
kubectl get scaledobject
kubectl get hpa
```

The consumer can scale to zero when no Kafka lag exists.

## 5. Publish messages

The easiest method in a VMware Ubuntu VM is port-forwarding:

```bash
kubectl port-forward service/kafka-producer 8080:8080
```

Keep that terminal open. In another terminal:

```bash
curl -X POST http://localhost:8080/orders/publish/100
```

## 6. Watch scaling

```bash
kubectl get pods -w
```

In another terminal:

```bash
watch -n 2 'kubectl get deployment kafka-consumer; echo; kubectl get hpa'
```

View consumer logs:

```bash
kubectl logs -l app=kafka-consumer --prefix=true --tail=200
```

Check actual Kafka lag:

```bash
kubectl exec deployment/kafka -- \
  /opt/kafka/bin/kafka-consumer-groups.sh \
  --bootstrap-server kafka:9092 \
  --group order-consumer-group \
  --describe
```

## Notes

- Topic partitions: 6
- Maximum consumer pods: 6
- Consumer concurrency per pod: 1
- Artificial processing delay: 2 seconds per message
- KEDA target: about 10 lagging records per replica
- The first activation from zero may briefly create one consumer before KEDA calculates the full desired replica count.
